## Volume Control
Control the volume of your system

## Description 
Control the volume of Mycroft with verbal commands or by spinning the physical
button on a Mark 1.  

## Examples 
* "Turn up the volume"
* "Decrease the audio"
* "Mute audio"
* "Set volume to 5"
* "Set volume to 75 percent"

## Credits 
Mycroft AI

