# Pairing Skill

## Usage:
* `pair my device`
* `register my device`
* `pair my unit`
